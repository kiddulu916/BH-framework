--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-08-04 15:51:24 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS bug_hunting_framework;
--
-- TOC entry 3847 (class 1262 OID 16384)
-- Name: bug_hunting_framework; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bug_hunting_framework WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE bug_hunting_framework OWNER TO postgres;

\connect bug_hunting_framework

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 3848 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3849 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 938 (class 1247 OID 16631)
-- Name: attackpathstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.attackpathstatus AS ENUM (
    'IDENTIFIED',
    'VERIFIED',
    'EXPLOITED',
    'BLOCKED',
    'FALSE_POSITIVE'
);


ALTER TYPE public.attackpathstatus OWNER TO postgres;

--
-- TOC entry 911 (class 1247 OID 16488)
-- Name: bugbountyplatform; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.bugbountyplatform AS ENUM (
    'HACKERONE',
    'BUGCROWD',
    'INTIGRITI',
    'YESWEHACK',
    'CUSTOM'
);


ALTER TYPE public.bugbountyplatform OWNER TO postgres;

--
-- TOC entry 944 (class 1247 OID 16665)
-- Name: portstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.portstatus AS ENUM (
    'OPEN',
    'CLOSED',
    'FILTERED',
    'UNFILTERED',
    'OPEN_FILTERED',
    'CLOSED_FILTERED',
    'UNKNOWN'
);


ALTER TYPE public.portstatus OWNER TO postgres;

--
-- TOC entry 989 (class 1247 OID 17022)
-- Name: reconcategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reconcategory AS ENUM (
    'DOMAIN_WHOIS',
    'SUBDOMAIN_ENUMERATION',
    'CERTIFICATE_TRANSPARENCY',
    'PUBLIC_REPOSITORIES',
    'SEARCH_ENGINE_DORKING',
    'DATA_BREACHES',
    'INFRASTRUCTURE_EXPOSURE',
    'ARCHIVE_HISTORICAL',
    'SOCIAL_MEDIA_OSINT',
    'CLOUD_ASSETS'
);


ALTER TYPE public.reconcategory OWNER TO postgres;

--
-- TOC entry 953 (class 1247 OID 16722)
-- Name: reportformat; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reportformat AS ENUM (
    'PDF',
    'HTML',
    'MARKDOWN',
    'JSON',
    'XML'
);


ALTER TYPE public.reportformat OWNER TO postgres;

--
-- TOC entry 956 (class 1247 OID 16734)
-- Name: reportstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reportstatus AS ENUM (
    'GENERATING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public.reportstatus OWNER TO postgres;

--
-- TOC entry 950 (class 1247 OID 16708)
-- Name: reporttype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reporttype AS ENUM (
    'EXECUTIVE_SUMMARY',
    'TECHNICAL_DETAILED',
    'VULNERABILITY_REPORT',
    'KILL_CHAIN_ANALYSIS',
    'COMPLIANCE_REPORT',
    'CUSTOM'
);


ALTER TYPE public.reporttype OWNER TO postgres;

--
-- TOC entry 983 (class 1247 OID 16916)
-- Name: servicestatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.servicestatus AS ENUM (
    'DETECTED',
    'CONFIRMED',
    'UNKNOWN'
);


ALTER TYPE public.servicestatus OWNER TO postgres;

--
-- TOC entry 962 (class 1247 OID 16777)
-- Name: subdomainstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.subdomainstatus AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'UNKNOWN'
);


ALTER TYPE public.subdomainstatus OWNER TO postgres;

--
-- TOC entry 908 (class 1247 OID 16483)
-- Name: targetstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.targetstatus AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.targetstatus OWNER TO postgres;

--
-- TOC entry 971 (class 1247 OID 16840)
-- Name: vulnerabilityseverity; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.vulnerabilityseverity AS ENUM (
    'CRITICAL',
    'HIGH',
    'MEDIUM',
    'LOW',
    'INFO'
);


ALTER TYPE public.vulnerabilityseverity OWNER TO postgres;

--
-- TOC entry 974 (class 1247 OID 16852)
-- Name: vulnerabilitystatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.vulnerabilitystatus AS ENUM (
    'OPEN',
    'VERIFIED',
    'FALSE_POSITIVE',
    'FIXED',
    'WONT_FIX',
    'DUPLICATE'
);


ALTER TYPE public.vulnerabilitystatus OWNER TO postgres;

--
-- TOC entry 968 (class 1247 OID 16808)
-- Name: vulnerabilitytype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.vulnerabilitytype AS ENUM (
    'SQL_INJECTION',
    'XSS',
    'CSRF',
    'SSRF',
    'RCE',
    'LFI',
    'RFI',
    'IDOR',
    'BROKEN_AUTH',
    'SENSITIVE_DATA_EXPOSURE',
    'SECURITY_MISCONFIGURATION',
    'INSECURE_DESERIALIZATION',
    'COMPONENTS_WITH_KNOWN_VULNERABILITIES',
    'INSUFFICIENT_LOGGING',
    'OTHER'
);


ALTER TYPE public.vulnerabilitytype OWNER TO postgres;

--
-- TOC entry 932 (class 1247 OID 16598)
-- Name: workflowstage; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workflowstage AS ENUM (
    'PASSIVE_RECON',
    'ACTIVE_RECON',
    'VULN_SCAN',
    'VULN_TEST',
    'KILL_CHAIN',
    'REPORT'
);


ALTER TYPE public.workflowstage OWNER TO postgres;

--
-- TOC entry 929 (class 1247 OID 16585)
-- Name: workflowstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workflowstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'COMPLETED',
    'FAILED',
    'CANCELLED',
    'PAUSED'
);


ALTER TYPE public.workflowstatus OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 16512)
-- Name: active_recon_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_recon_results (
    execution_id character varying(255) NOT NULL,
    tools_used jsonb,
    configuration jsonb,
    scan_type character varying(100),
    hosts_scanned jsonb NOT NULL,
    total_hosts_scanned integer NOT NULL,
    hosts_with_open_ports integer NOT NULL,
    total_open_ports integer NOT NULL,
    total_services_detected integer NOT NULL,
    raw_output jsonb,
    processed_data jsonb,
    execution_time double precision,
    errors jsonb,
    target_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.active_recon_results OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16477)
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 17133)
-- Name: archive_findings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archive_findings (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    archive_source character varying(50) NOT NULL,
    finding_type character varying(100) NOT NULL,
    original_url character varying(500),
    archived_url character varying(500),
    archive_date character varying(50),
    content text,
    parameters jsonb,
    secrets_found jsonb,
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.archive_findings OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16641)
-- Name: attack_paths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attack_paths (
    name character varying(500) NOT NULL,
    description text,
    status public.attackpathstatus NOT NULL,
    attack_path_type character varying(100),
    severity character varying(50),
    stages jsonb,
    entry_points jsonb,
    exit_points jsonb,
    prerequisites jsonb,
    techniques jsonb,
    tools_required jsonb,
    evidence text,
    proof_of_concept text,
    screenshots jsonb,
    risk_score double precision,
    impact_assessment text,
    remediation text,
    attack_path_metadata jsonb,
    phases jsonb,
    tactics jsonb,
    intermediate_nodes jsonb,
    likelihood character varying(50),
    impact character varying(50),
    is_verified boolean NOT NULL,
    verification_evidence jsonb,
    verification_notes text,
    is_exploitable boolean NOT NULL,
    exploitation_evidence jsonb,
    exploitation_notes text,
    mitigation_controls jsonb,
    recommended_controls jsonb,
    tags jsonb,
    notes text,
    kill_chain_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.attack_paths OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 17103)
-- Name: breach_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.breach_records (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    breach_source character varying(255) NOT NULL,
    breach_type character varying(100) NOT NULL,
    email character varying(255),
    username character varying(255),
    password_hash character varying(255),
    personal_info jsonb,
    breach_date character varying(50),
    breach_name character varying(255),
    severity character varying(50),
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.breach_records OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 17058)
-- Name: certificate_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificate_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    domain character varying(500) NOT NULL,
    certificate_id character varying(255),
    issuer character varying(255),
    subject_alt_names jsonb,
    not_before character varying(50),
    not_after character varying(50),
    serial_number character varying(255),
    fingerprint character varying(255),
    log_index character varying(255),
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.certificate_logs OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 17163)
-- Name: cloud_assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cloud_assets (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    provider character varying(50) NOT NULL,
    asset_type character varying(100) NOT NULL,
    asset_name character varying(255),
    asset_url character varying(500),
    is_public boolean NOT NULL,
    permissions jsonb,
    contents jsonb,
    misconfiguration text,
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.cloud_assets OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 17118)
-- Name: infrastructure_exposures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.infrastructure_exposures (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    source character varying(50) NOT NULL,
    ip_address character varying(45),
    port integer,
    service character varying(100),
    banner text,
    ssl_info jsonb,
    vulnerabilities jsonb,
    location jsonb,
    organization character varying(255),
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.infrastructure_exposures OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16530)
-- Name: kill_chains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kill_chains (
    execution_id character varying(255),
    total_paths_identified integer NOT NULL,
    critical_paths integer NOT NULL,
    high_paths integer NOT NULL,
    medium_paths integer NOT NULL,
    low_paths integer NOT NULL,
    info_paths integer NOT NULL,
    verified_paths integer NOT NULL,
    execution_time double precision,
    analysis_config jsonb,
    raw_output jsonb,
    kill_chain_metadata jsonb,
    analysis_type character varying(100),
    methodology character varying(255),
    configuration jsonb,
    exploitable_paths integer NOT NULL,
    blocked_paths integer NOT NULL,
    raw_analysis jsonb,
    processed_paths jsonb,
    errors jsonb,
    target_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.kill_chains OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16548)
-- Name: passive_recon_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passive_recon_results (
    execution_id character varying(255) NOT NULL,
    tools_used jsonb,
    configuration jsonb,
    total_subdomains integer NOT NULL,
    unique_subdomains integer NOT NULL,
    total_ips integer NOT NULL,
    unique_ips integer NOT NULL,
    raw_output jsonb,
    processed_data jsonb,
    execution_time character varying(50),
    errors jsonb,
    extra_metadata jsonb,
    target_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.passive_recon_results OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16679)
-- Name: ports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ports (
    host character varying(255) NOT NULL,
    port_number integer NOT NULL,
    protocol character varying(10) NOT NULL,
    status public.portstatus NOT NULL,
    is_open boolean NOT NULL,
    service_name character varying(255),
    service_version character varying(255),
    service_product character varying(255),
    banner text,
    script_output jsonb,
    notes text,
    active_recon_result_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.ports OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 16743)
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    name character varying(255) NOT NULL,
    report_type public.reporttype NOT NULL,
    format public.reportformat NOT NULL,
    status public.reportstatus NOT NULL,
    is_public boolean NOT NULL,
    content text,
    file_path character varying(1000),
    file_size character varying(50),
    template_used character varying(255),
    configuration jsonb,
    summary text,
    key_findings jsonb,
    statistics jsonb,
    generation_time character varying(50),
    generated_by character varying(255),
    errors jsonb,
    access_token character varying(255),
    expires_at character varying(50),
    target_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 17073)
-- Name: repository_findings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repository_findings (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    platform character varying(50) NOT NULL,
    repository_url character varying(500),
    file_path character varying(500),
    finding_type character varying(100) NOT NULL,
    content text,
    line_number integer,
    commit_hash character varying(255),
    severity character varying(50),
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.repository_findings OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 17088)
-- Name: search_dork_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_dork_results (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    search_query character varying(500) NOT NULL,
    result_type character varying(100) NOT NULL,
    url character varying(500),
    title character varying(500),
    snippet text,
    file_type character varying(50),
    file_size character varying(50),
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.search_dork_results OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 16923)
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    name character varying(255) NOT NULL,
    version character varying(255),
    product character varying(255),
    extrainfo character varying(500),
    status public.servicestatus NOT NULL,
    is_confirmed boolean NOT NULL,
    banner text,
    fingerprint jsonb,
    cpe character varying(500),
    tags jsonb,
    notes text,
    port_id uuid NOT NULL,
    active_recon_result_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 17148)
-- Name: social_media_intel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_media_intel (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    platform character varying(50) NOT NULL,
    intel_type character varying(100) NOT NULL,
    username character varying(255),
    profile_url character varying(500),
    content text,
    intel_metadata jsonb,
    relevance_score integer,
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.social_media_intel OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16783)
-- Name: subdomains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subdomains (
    name character varying(500) NOT NULL,
    domain character varying(255) NOT NULL,
    subdomain_part character varying(255) NOT NULL,
    status public.subdomainstatus NOT NULL,
    is_verified boolean NOT NULL,
    ip_addresses jsonb,
    cname character varying(500),
    mx_records jsonb,
    txt_records jsonb,
    ns_records jsonb,
    sources jsonb,
    first_seen character varying(50),
    last_seen character varying(50),
    tags jsonb,
    notes text,
    extra_metadata jsonb,
    passive_recon_result_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.subdomains OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16499)
-- Name: targets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.targets (
    target character varying(255),
    domain character varying(500),
    is_primary boolean NOT NULL,
    status public.targetstatus NOT NULL,
    platform public.bugbountyplatform,
    login_email character varying(255),
    researcher_email character varying(255),
    in_scope jsonb,
    out_of_scope jsonb,
    rate_limit_requests integer,
    rate_limit_seconds integer,
    custom_headers jsonb,
    additional_info jsonb,
    notes text,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.targets OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16566)
-- Name: vulnerabilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vulnerabilities (
    execution_id character varying(255) NOT NULL,
    scan_type character varying(100),
    tools_used jsonb,
    configuration jsonb,
    scan_targets jsonb,
    total_findings integer NOT NULL,
    critical_findings integer NOT NULL,
    high_findings integer NOT NULL,
    medium_findings integer NOT NULL,
    low_findings integer NOT NULL,
    info_findings integer NOT NULL,
    raw_output jsonb,
    processed_data jsonb,
    execution_time character varying(50),
    errors jsonb,
    target_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.vulnerabilities OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16865)
-- Name: vulnerability_findings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vulnerability_findings (
    title character varying(500) NOT NULL,
    vuln_type public.vulnerabilitytype NOT NULL,
    severity public.vulnerabilityseverity NOT NULL,
    status public.vulnerabilitystatus NOT NULL,
    description text,
    cve_id character varying(50),
    cvss_score double precision,
    cvss_vector character varying(100),
    affected_host character varying(255),
    affected_port integer,
    affected_service character varying(255),
    affected_url character varying(1000),
    proof_of_concept text,
    remediation text,
    "references" jsonb,
    detection_tool character varying(255),
    detection_method character varying(255),
    confidence character varying(50),
    is_verified boolean NOT NULL,
    verification_notes text,
    tags jsonb,
    notes text,
    vulnerability_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.vulnerability_findings OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 17043)
-- Name: whois_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whois_records (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    domain character varying(500) NOT NULL,
    registrar character varying(255),
    registrant_name character varying(255),
    registrant_email character varying(255),
    registrant_organization character varying(255),
    creation_date character varying(50),
    expiration_date character varying(50),
    updated_date character varying(50),
    name_servers jsonb,
    status jsonb,
    raw_data text,
    passive_recon_result_id uuid NOT NULL
);


ALTER TABLE public.whois_records OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16894)
-- Name: workflow_executions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_executions (
    stage public.workflowstage NOT NULL,
    execution_id character varying(255) NOT NULL,
    status public.workflowstatus NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    configuration jsonb,
    results jsonb,
    errors jsonb,
    progress_percentage character varying(10),
    current_step character varying(255),
    workflow_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.workflow_executions OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16611)
-- Name: workflows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflows (
    name character varying(255) NOT NULL,
    description text,
    stages jsonb NOT NULL,
    dependencies jsonb,
    settings jsonb,
    status public.workflowstatus NOT NULL,
    current_stage public.workflowstage,
    progress character varying(50),
    target_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    notes text
);


ALTER TABLE public.workflows OWNER TO postgres;

--
-- TOC entry 3821 (class 0 OID 16512)
-- Dependencies: 218
-- Data for Name: active_recon_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_recon_results (execution_id, tools_used, configuration, scan_type, hosts_scanned, total_hosts_scanned, hosts_with_open_ports, total_open_ports, total_services_detected, raw_output, processed_data, execution_time, errors, target_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3819 (class 0 OID 16477)
-- Dependencies: 216
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
enhanced_osint_models
\.


--
-- TOC entry 3839 (class 0 OID 17133)
-- Dependencies: 236
-- Data for Name: archive_findings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.archive_findings (id, created_at, updated_at, archive_source, finding_type, original_url, archived_url, archive_date, content, parameters, secrets_found, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3826 (class 0 OID 16641)
-- Dependencies: 223
-- Data for Name: attack_paths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attack_paths (name, description, status, attack_path_type, severity, stages, entry_points, exit_points, prerequisites, techniques, tools_required, evidence, proof_of_concept, screenshots, risk_score, impact_assessment, remediation, attack_path_metadata, phases, tactics, intermediate_nodes, likelihood, impact, is_verified, verification_evidence, verification_notes, is_exploitable, exploitation_evidence, exploitation_notes, mitigation_controls, recommended_controls, tags, notes, kill_chain_id, id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3837 (class 0 OID 17103)
-- Dependencies: 234
-- Data for Name: breach_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.breach_records (id, created_at, updated_at, breach_source, breach_type, email, username, password_hash, personal_info, breach_date, breach_name, severity, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3834 (class 0 OID 17058)
-- Dependencies: 231
-- Data for Name: certificate_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificate_logs (id, created_at, updated_at, domain, certificate_id, issuer, subject_alt_names, not_before, not_after, serial_number, fingerprint, log_index, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3841 (class 0 OID 17163)
-- Dependencies: 238
-- Data for Name: cloud_assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cloud_assets (id, created_at, updated_at, provider, asset_type, asset_name, asset_url, is_public, permissions, contents, misconfiguration, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3838 (class 0 OID 17118)
-- Dependencies: 235
-- Data for Name: infrastructure_exposures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.infrastructure_exposures (id, created_at, updated_at, source, ip_address, port, service, banner, ssl_info, vulnerabilities, location, organization, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3822 (class 0 OID 16530)
-- Dependencies: 219
-- Data for Name: kill_chains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kill_chains (execution_id, total_paths_identified, critical_paths, high_paths, medium_paths, low_paths, info_paths, verified_paths, execution_time, analysis_config, raw_output, kill_chain_metadata, analysis_type, methodology, configuration, exploitable_paths, blocked_paths, raw_analysis, processed_paths, errors, target_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3823 (class 0 OID 16548)
-- Dependencies: 220
-- Data for Name: passive_recon_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passive_recon_results (execution_id, tools_used, configuration, total_subdomains, unique_subdomains, total_ips, unique_ips, raw_output, processed_data, execution_time, errors, extra_metadata, target_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3827 (class 0 OID 16679)
-- Dependencies: 224
-- Data for Name: ports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ports (host, port_number, protocol, status, is_open, service_name, service_version, service_product, banner, script_output, notes, active_recon_result_id, id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3828 (class 0 OID 16743)
-- Dependencies: 225
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (name, report_type, format, status, is_public, content, file_path, file_size, template_used, configuration, summary, key_findings, statistics, generation_time, generated_by, errors, access_token, expires_at, target_id, workflow_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3835 (class 0 OID 17073)
-- Dependencies: 232
-- Data for Name: repository_findings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.repository_findings (id, created_at, updated_at, platform, repository_url, file_path, finding_type, content, line_number, commit_hash, severity, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3836 (class 0 OID 17088)
-- Dependencies: 233
-- Data for Name: search_dork_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_dork_results (id, created_at, updated_at, search_query, result_type, url, title, snippet, file_type, file_size, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3832 (class 0 OID 16923)
-- Dependencies: 229
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (name, version, product, extrainfo, status, is_confirmed, banner, fingerprint, cpe, tags, notes, port_id, active_recon_result_id, id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3840 (class 0 OID 17148)
-- Dependencies: 237
-- Data for Name: social_media_intel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_media_intel (id, created_at, updated_at, platform, intel_type, username, profile_url, content, intel_metadata, relevance_score, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3829 (class 0 OID 16783)
-- Dependencies: 226
-- Data for Name: subdomains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subdomains (name, domain, subdomain_part, status, is_verified, ip_addresses, cname, mx_records, txt_records, ns_records, sources, first_seen, last_seen, tags, notes, extra_metadata, passive_recon_result_id, id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3820 (class 0 OID 16499)
-- Dependencies: 217
-- Data for Name: targets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.targets (target, domain, is_primary, status, platform, login_email, researcher_email, in_scope, out_of_scope, rate_limit_requests, rate_limit_seconds, custom_headers, additional_info, notes, id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3824 (class 0 OID 16566)
-- Dependencies: 221
-- Data for Name: vulnerabilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vulnerabilities (execution_id, scan_type, tools_used, configuration, scan_targets, total_findings, critical_findings, high_findings, medium_findings, low_findings, info_findings, raw_output, processed_data, execution_time, errors, target_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3830 (class 0 OID 16865)
-- Dependencies: 227
-- Data for Name: vulnerability_findings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vulnerability_findings (title, vuln_type, severity, status, description, cve_id, cvss_score, cvss_vector, affected_host, affected_port, affected_service, affected_url, proof_of_concept, remediation, "references", detection_tool, detection_method, confidence, is_verified, verification_notes, tags, notes, vulnerability_id, id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3833 (class 0 OID 17043)
-- Dependencies: 230
-- Data for Name: whois_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.whois_records (id, created_at, updated_at, domain, registrar, registrant_name, registrant_email, registrant_organization, creation_date, expiration_date, updated_date, name_servers, status, raw_data, passive_recon_result_id) FROM stdin;
\.


--
-- TOC entry 3831 (class 0 OID 16894)
-- Dependencies: 228
-- Data for Name: workflow_executions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_executions (stage, execution_id, status, started_at, completed_at, configuration, results, errors, progress_percentage, current_step, workflow_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3825 (class 0 OID 16611)
-- Dependencies: 222
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflows (name, description, stages, dependencies, settings, status, current_stage, progress, target_id, id, created_at, updated_at, notes) FROM stdin;
\.


--
-- TOC entry 3463 (class 2606 OID 16518)
-- Name: active_recon_results active_recon_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_recon_results
    ADD CONSTRAINT active_recon_results_pkey PRIMARY KEY (id);


--
-- TOC entry 3453 (class 2606 OID 16481)
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- TOC entry 3640 (class 2606 OID 17139)
-- Name: archive_findings archive_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archive_findings
    ADD CONSTRAINT archive_findings_pkey PRIMARY KEY (id);


--
-- TOC entry 3504 (class 2606 OID 16647)
-- Name: attack_paths attack_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attack_paths
    ADD CONSTRAINT attack_paths_pkey PRIMARY KEY (id);


--
-- TOC entry 3630 (class 2606 OID 17109)
-- Name: breach_records breach_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.breach_records
    ADD CONSTRAINT breach_records_pkey PRIMARY KEY (id);


--
-- TOC entry 3615 (class 2606 OID 17064)
-- Name: certificate_logs certificate_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificate_logs
    ADD CONSTRAINT certificate_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3650 (class 2606 OID 17169)
-- Name: cloud_assets cloud_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cloud_assets
    ADD CONSTRAINT cloud_assets_pkey PRIMARY KEY (id);


--
-- TOC entry 3638 (class 2606 OID 17124)
-- Name: infrastructure_exposures infrastructure_exposures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infrastructure_exposures
    ADD CONSTRAINT infrastructure_exposures_pkey PRIMARY KEY (id);


--
-- TOC entry 3477 (class 2606 OID 16536)
-- Name: kill_chains kill_chains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kill_chains
    ADD CONSTRAINT kill_chains_pkey PRIMARY KEY (id);


--
-- TOC entry 3485 (class 2606 OID 16554)
-- Name: passive_recon_results passive_recon_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passive_recon_results
    ADD CONSTRAINT passive_recon_results_pkey PRIMARY KEY (id);


--
-- TOC entry 3533 (class 2606 OID 16685)
-- Name: ports ports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ports
    ADD CONSTRAINT ports_pkey PRIMARY KEY (id);


--
-- TOC entry 3551 (class 2606 OID 16749)
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- TOC entry 3623 (class 2606 OID 17079)
-- Name: repository_findings repository_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repository_findings
    ADD CONSTRAINT repository_findings_pkey PRIMARY KEY (id);


--
-- TOC entry 3628 (class 2606 OID 17094)
-- Name: search_dork_results search_dork_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_dork_results
    ADD CONSTRAINT search_dork_results_pkey PRIMARY KEY (id);


--
-- TOC entry 3608 (class 2606 OID 16929)
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- TOC entry 3648 (class 2606 OID 17154)
-- Name: social_media_intel social_media_intel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_media_intel
    ADD CONSTRAINT social_media_intel_pkey PRIMARY KEY (id);


--
-- TOC entry 3565 (class 2606 OID 16789)
-- Name: subdomains subdomains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subdomains
    ADD CONSTRAINT subdomains_pkey PRIMARY KEY (id);


--
-- TOC entry 3461 (class 2606 OID 16505)
-- Name: targets targets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.targets
    ADD CONSTRAINT targets_pkey PRIMARY KEY (id);


--
-- TOC entry 3493 (class 2606 OID 16572)
-- Name: vulnerabilities vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vulnerabilities
    ADD CONSTRAINT vulnerabilities_pkey PRIMARY KEY (id);


--
-- TOC entry 3584 (class 2606 OID 16871)
-- Name: vulnerability_findings vulnerability_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vulnerability_findings
    ADD CONSTRAINT vulnerability_findings_pkey PRIMARY KEY (id);


--
-- TOC entry 3613 (class 2606 OID 17049)
-- Name: whois_records whois_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whois_records
    ADD CONSTRAINT whois_records_pkey PRIMARY KEY (id);


--
-- TOC entry 3595 (class 2606 OID 16900)
-- Name: workflow_executions workflow_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 3502 (class 2606 OID 16617)
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- TOC entry 3464 (class 1259 OID 16524)
-- Name: idx_active_recon_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_active_recon_created ON public.active_recon_results USING btree (created_at);


--
-- TOC entry 3465 (class 1259 OID 16525)
-- Name: idx_active_recon_execution; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_active_recon_execution ON public.active_recon_results USING btree (execution_id);


--
-- TOC entry 3466 (class 1259 OID 16526)
-- Name: idx_active_recon_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_active_recon_target ON public.active_recon_results USING btree (target_id);


--
-- TOC entry 3641 (class 1259 OID 17147)
-- Name: idx_archive_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_archive_passive_recon ON public.archive_findings USING btree (passive_recon_result_id);


--
-- TOC entry 3642 (class 1259 OID 17145)
-- Name: idx_archive_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_archive_source ON public.archive_findings USING btree (archive_source);


--
-- TOC entry 3643 (class 1259 OID 17146)
-- Name: idx_archive_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_archive_type ON public.archive_findings USING btree (finding_type);


--
-- TOC entry 3505 (class 1259 OID 16653)
-- Name: idx_attack_paths_exploitable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attack_paths_exploitable ON public.attack_paths USING btree (is_exploitable);


--
-- TOC entry 3506 (class 1259 OID 16654)
-- Name: idx_attack_paths_kill_chain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attack_paths_kill_chain ON public.attack_paths USING btree (kill_chain_id);


--
-- TOC entry 3507 (class 1259 OID 16655)
-- Name: idx_attack_paths_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attack_paths_name ON public.attack_paths USING btree (name);


--
-- TOC entry 3508 (class 1259 OID 16656)
-- Name: idx_attack_paths_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attack_paths_status ON public.attack_paths USING btree (status);


--
-- TOC entry 3509 (class 1259 OID 16657)
-- Name: idx_attack_paths_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attack_paths_verified ON public.attack_paths USING btree (is_verified);


--
-- TOC entry 3631 (class 1259 OID 17117)
-- Name: idx_breach_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_breach_passive_recon ON public.breach_records USING btree (passive_recon_result_id);


--
-- TOC entry 3632 (class 1259 OID 17115)
-- Name: idx_breach_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_breach_source ON public.breach_records USING btree (breach_source);


--
-- TOC entry 3633 (class 1259 OID 17116)
-- Name: idx_breach_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_breach_type ON public.breach_records USING btree (breach_type);


--
-- TOC entry 3616 (class 1259 OID 17070)
-- Name: idx_cert_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cert_domain ON public.certificate_logs USING btree (domain);


--
-- TOC entry 3617 (class 1259 OID 17071)
-- Name: idx_cert_issuer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cert_issuer ON public.certificate_logs USING btree (issuer);


--
-- TOC entry 3618 (class 1259 OID 17072)
-- Name: idx_cert_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cert_passive_recon ON public.certificate_logs USING btree (passive_recon_result_id);


--
-- TOC entry 3651 (class 1259 OID 17177)
-- Name: idx_cloud_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cloud_passive_recon ON public.cloud_assets USING btree (passive_recon_result_id);


--
-- TOC entry 3652 (class 1259 OID 17175)
-- Name: idx_cloud_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cloud_provider ON public.cloud_assets USING btree (provider);


--
-- TOC entry 3653 (class 1259 OID 17176)
-- Name: idx_cloud_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cloud_type ON public.cloud_assets USING btree (asset_type);


--
-- TOC entry 3624 (class 1259 OID 17102)
-- Name: idx_dork_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dork_passive_recon ON public.search_dork_results USING btree (passive_recon_result_id);


--
-- TOC entry 3625 (class 1259 OID 17100)
-- Name: idx_dork_query; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dork_query ON public.search_dork_results USING btree (search_query);


--
-- TOC entry 3626 (class 1259 OID 17101)
-- Name: idx_dork_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dork_type ON public.search_dork_results USING btree (result_type);


--
-- TOC entry 3634 (class 1259 OID 17132)
-- Name: idx_infra_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_infra_passive_recon ON public.infrastructure_exposures USING btree (passive_recon_result_id);


--
-- TOC entry 3635 (class 1259 OID 17131)
-- Name: idx_infra_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_infra_service ON public.infrastructure_exposures USING btree (service);


--
-- TOC entry 3636 (class 1259 OID 17130)
-- Name: idx_infra_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_infra_source ON public.infrastructure_exposures USING btree (source);


--
-- TOC entry 3470 (class 1259 OID 16542)
-- Name: idx_kill_chains_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kill_chains_created ON public.kill_chains USING btree (created_at);


--
-- TOC entry 3471 (class 1259 OID 16543)
-- Name: idx_kill_chains_execution; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kill_chains_execution ON public.kill_chains USING btree (execution_id);


--
-- TOC entry 3472 (class 1259 OID 16544)
-- Name: idx_kill_chains_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kill_chains_target ON public.kill_chains USING btree (target_id);


--
-- TOC entry 3478 (class 1259 OID 16560)
-- Name: idx_passive_recon_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_passive_recon_created ON public.passive_recon_results USING btree (created_at);


--
-- TOC entry 3479 (class 1259 OID 16561)
-- Name: idx_passive_recon_execution; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_passive_recon_execution ON public.passive_recon_results USING btree (execution_id);


--
-- TOC entry 3480 (class 1259 OID 16562)
-- Name: idx_passive_recon_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_passive_recon_target ON public.passive_recon_results USING btree (target_id);


--
-- TOC entry 3516 (class 1259 OID 16691)
-- Name: idx_ports_active_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_active_recon ON public.ports USING btree (active_recon_result_id);


--
-- TOC entry 3517 (class 1259 OID 16692)
-- Name: idx_ports_host; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_host ON public.ports USING btree (host);


--
-- TOC entry 3518 (class 1259 OID 16693)
-- Name: idx_ports_host_port; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_host_port ON public.ports USING btree (host, port_number, protocol);


--
-- TOC entry 3519 (class 1259 OID 16694)
-- Name: idx_ports_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_number ON public.ports USING btree (port_number);


--
-- TOC entry 3520 (class 1259 OID 16695)
-- Name: idx_ports_open; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_open ON public.ports USING btree (is_open);


--
-- TOC entry 3521 (class 1259 OID 16696)
-- Name: idx_ports_protocol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_protocol ON public.ports USING btree (protocol);


--
-- TOC entry 3522 (class 1259 OID 16697)
-- Name: idx_ports_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_service ON public.ports USING btree (service_name);


--
-- TOC entry 3523 (class 1259 OID 16698)
-- Name: idx_ports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ports_status ON public.ports USING btree (status);


--
-- TOC entry 3619 (class 1259 OID 17087)
-- Name: idx_repo_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_repo_passive_recon ON public.repository_findings USING btree (passive_recon_result_id);


--
-- TOC entry 3620 (class 1259 OID 17085)
-- Name: idx_repo_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_repo_platform ON public.repository_findings USING btree (platform);


--
-- TOC entry 3621 (class 1259 OID 17086)
-- Name: idx_repo_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_repo_type ON public.repository_findings USING btree (finding_type);


--
-- TOC entry 3534 (class 1259 OID 16760)
-- Name: idx_reports_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_created ON public.reports USING btree (created_at);


--
-- TOC entry 3535 (class 1259 OID 16761)
-- Name: idx_reports_format; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_format ON public.reports USING btree (format);


--
-- TOC entry 3536 (class 1259 OID 16762)
-- Name: idx_reports_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_name ON public.reports USING btree (name);


--
-- TOC entry 3537 (class 1259 OID 16763)
-- Name: idx_reports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_status ON public.reports USING btree (status);


--
-- TOC entry 3538 (class 1259 OID 16764)
-- Name: idx_reports_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_target ON public.reports USING btree (target_id);


--
-- TOC entry 3539 (class 1259 OID 16765)
-- Name: idx_reports_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_type ON public.reports USING btree (report_type);


--
-- TOC entry 3540 (class 1259 OID 16766)
-- Name: idx_reports_workflow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_workflow ON public.reports USING btree (workflow_id);


--
-- TOC entry 3596 (class 1259 OID 16940)
-- Name: idx_services_active_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_active_recon ON public.services USING btree (active_recon_result_id);


--
-- TOC entry 3597 (class 1259 OID 16941)
-- Name: idx_services_confirmed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_confirmed ON public.services USING btree (is_confirmed);


--
-- TOC entry 3598 (class 1259 OID 16942)
-- Name: idx_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_name ON public.services USING btree (name);


--
-- TOC entry 3599 (class 1259 OID 16943)
-- Name: idx_services_port; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_port ON public.services USING btree (port_id);


--
-- TOC entry 3600 (class 1259 OID 16944)
-- Name: idx_services_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_product ON public.services USING btree (product);


--
-- TOC entry 3601 (class 1259 OID 16945)
-- Name: idx_services_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_status ON public.services USING btree (status);


--
-- TOC entry 3644 (class 1259 OID 17162)
-- Name: idx_social_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_social_passive_recon ON public.social_media_intel USING btree (passive_recon_result_id);


--
-- TOC entry 3645 (class 1259 OID 17160)
-- Name: idx_social_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_social_platform ON public.social_media_intel USING btree (platform);


--
-- TOC entry 3646 (class 1259 OID 17161)
-- Name: idx_social_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_social_type ON public.social_media_intel USING btree (intel_type);


--
-- TOC entry 3552 (class 1259 OID 16795)
-- Name: idx_subdomains_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subdomains_domain ON public.subdomains USING btree (domain);


--
-- TOC entry 3553 (class 1259 OID 16796)
-- Name: idx_subdomains_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subdomains_name ON public.subdomains USING btree (name);


--
-- TOC entry 3554 (class 1259 OID 16797)
-- Name: idx_subdomains_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subdomains_passive_recon ON public.subdomains USING btree (passive_recon_result_id);


--
-- TOC entry 3555 (class 1259 OID 16798)
-- Name: idx_subdomains_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subdomains_status ON public.subdomains USING btree (status);


--
-- TOC entry 3556 (class 1259 OID 16799)
-- Name: idx_subdomains_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subdomains_verified ON public.subdomains USING btree (is_verified);


--
-- TOC entry 3454 (class 1259 OID 16506)
-- Name: idx_targets_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_targets_domain ON public.targets USING btree (domain);


--
-- TOC entry 3455 (class 1259 OID 16507)
-- Name: idx_targets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_targets_status ON public.targets USING btree (status);


--
-- TOC entry 3486 (class 1259 OID 16578)
-- Name: idx_vulnerabilities_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerabilities_created ON public.vulnerabilities USING btree (created_at);


--
-- TOC entry 3487 (class 1259 OID 16579)
-- Name: idx_vulnerabilities_execution; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerabilities_execution ON public.vulnerabilities USING btree (execution_id);


--
-- TOC entry 3488 (class 1259 OID 16580)
-- Name: idx_vulnerabilities_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerabilities_target ON public.vulnerabilities USING btree (target_id);


--
-- TOC entry 3566 (class 1259 OID 16877)
-- Name: idx_vulnerability_findings_cve; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_cve ON public.vulnerability_findings USING btree (cve_id);


--
-- TOC entry 3567 (class 1259 OID 16878)
-- Name: idx_vulnerability_findings_host; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_host ON public.vulnerability_findings USING btree (affected_host);


--
-- TOC entry 3568 (class 1259 OID 16879)
-- Name: idx_vulnerability_findings_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_severity ON public.vulnerability_findings USING btree (severity);


--
-- TOC entry 3569 (class 1259 OID 16880)
-- Name: idx_vulnerability_findings_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_status ON public.vulnerability_findings USING btree (status);


--
-- TOC entry 3570 (class 1259 OID 16881)
-- Name: idx_vulnerability_findings_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_title ON public.vulnerability_findings USING btree (title);


--
-- TOC entry 3571 (class 1259 OID 16882)
-- Name: idx_vulnerability_findings_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_type ON public.vulnerability_findings USING btree (vuln_type);


--
-- TOC entry 3572 (class 1259 OID 16883)
-- Name: idx_vulnerability_findings_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_verified ON public.vulnerability_findings USING btree (is_verified);


--
-- TOC entry 3573 (class 1259 OID 16884)
-- Name: idx_vulnerability_findings_vulnerability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vulnerability_findings_vulnerability ON public.vulnerability_findings USING btree (vulnerability_id);


--
-- TOC entry 3609 (class 1259 OID 17055)
-- Name: idx_whois_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whois_domain ON public.whois_records USING btree (domain);


--
-- TOC entry 3610 (class 1259 OID 17057)
-- Name: idx_whois_passive_recon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whois_passive_recon ON public.whois_records USING btree (passive_recon_result_id);


--
-- TOC entry 3611 (class 1259 OID 17056)
-- Name: idx_whois_registrar; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whois_registrar ON public.whois_records USING btree (registrar);


--
-- TOC entry 3585 (class 1259 OID 16906)
-- Name: idx_workflow_executions_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_executions_execution_id ON public.workflow_executions USING btree (execution_id);


--
-- TOC entry 3586 (class 1259 OID 16907)
-- Name: idx_workflow_executions_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_executions_stage ON public.workflow_executions USING btree (stage);


--
-- TOC entry 3587 (class 1259 OID 16908)
-- Name: idx_workflow_executions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_executions_status ON public.workflow_executions USING btree (status);


--
-- TOC entry 3588 (class 1259 OID 16909)
-- Name: idx_workflow_executions_workflow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_executions_workflow ON public.workflow_executions USING btree (workflow_id);


--
-- TOC entry 3494 (class 1259 OID 16623)
-- Name: idx_workflows_current_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_current_stage ON public.workflows USING btree (current_stage);


--
-- TOC entry 3495 (class 1259 OID 16624)
-- Name: idx_workflows_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_status ON public.workflows USING btree (status);


--
-- TOC entry 3496 (class 1259 OID 16625)
-- Name: idx_workflows_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_target ON public.workflows USING btree (target_id);


--
-- TOC entry 3467 (class 1259 OID 16527)
-- Name: ix_public_active_recon_results_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_active_recon_results_created_at ON public.active_recon_results USING btree (created_at);


--
-- TOC entry 3468 (class 1259 OID 16528)
-- Name: ix_public_active_recon_results_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_active_recon_results_execution_id ON public.active_recon_results USING btree (execution_id);


--
-- TOC entry 3469 (class 1259 OID 16529)
-- Name: ix_public_active_recon_results_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_active_recon_results_id ON public.active_recon_results USING btree (id);


--
-- TOC entry 3510 (class 1259 OID 16658)
-- Name: ix_public_attack_paths_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_attack_paths_created_at ON public.attack_paths USING btree (created_at);


--
-- TOC entry 3511 (class 1259 OID 16659)
-- Name: ix_public_attack_paths_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_attack_paths_id ON public.attack_paths USING btree (id);


--
-- TOC entry 3512 (class 1259 OID 16660)
-- Name: ix_public_attack_paths_is_exploitable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_attack_paths_is_exploitable ON public.attack_paths USING btree (is_exploitable);


--
-- TOC entry 3513 (class 1259 OID 16661)
-- Name: ix_public_attack_paths_is_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_attack_paths_is_verified ON public.attack_paths USING btree (is_verified);


--
-- TOC entry 3514 (class 1259 OID 16662)
-- Name: ix_public_attack_paths_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_attack_paths_name ON public.attack_paths USING btree (name);


--
-- TOC entry 3515 (class 1259 OID 16663)
-- Name: ix_public_attack_paths_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_attack_paths_status ON public.attack_paths USING btree (status);


--
-- TOC entry 3473 (class 1259 OID 16545)
-- Name: ix_public_kill_chains_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_kill_chains_created_at ON public.kill_chains USING btree (created_at);


--
-- TOC entry 3474 (class 1259 OID 16546)
-- Name: ix_public_kill_chains_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_kill_chains_execution_id ON public.kill_chains USING btree (execution_id);


--
-- TOC entry 3475 (class 1259 OID 16547)
-- Name: ix_public_kill_chains_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_kill_chains_id ON public.kill_chains USING btree (id);


--
-- TOC entry 3481 (class 1259 OID 16563)
-- Name: ix_public_passive_recon_results_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_passive_recon_results_created_at ON public.passive_recon_results USING btree (created_at);


--
-- TOC entry 3482 (class 1259 OID 16564)
-- Name: ix_public_passive_recon_results_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_passive_recon_results_execution_id ON public.passive_recon_results USING btree (execution_id);


--
-- TOC entry 3483 (class 1259 OID 16565)
-- Name: ix_public_passive_recon_results_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_passive_recon_results_id ON public.passive_recon_results USING btree (id);


--
-- TOC entry 3524 (class 1259 OID 16699)
-- Name: ix_public_ports_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_created_at ON public.ports USING btree (created_at);


--
-- TOC entry 3525 (class 1259 OID 16700)
-- Name: ix_public_ports_host; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_host ON public.ports USING btree (host);


--
-- TOC entry 3526 (class 1259 OID 16701)
-- Name: ix_public_ports_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_id ON public.ports USING btree (id);


--
-- TOC entry 3527 (class 1259 OID 16702)
-- Name: ix_public_ports_is_open; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_is_open ON public.ports USING btree (is_open);


--
-- TOC entry 3528 (class 1259 OID 16703)
-- Name: ix_public_ports_port_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_port_number ON public.ports USING btree (port_number);


--
-- TOC entry 3529 (class 1259 OID 16704)
-- Name: ix_public_ports_protocol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_protocol ON public.ports USING btree (protocol);


--
-- TOC entry 3530 (class 1259 OID 16705)
-- Name: ix_public_ports_service_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_service_name ON public.ports USING btree (service_name);


--
-- TOC entry 3531 (class 1259 OID 16706)
-- Name: ix_public_ports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_ports_status ON public.ports USING btree (status);


--
-- TOC entry 3541 (class 1259 OID 16767)
-- Name: ix_public_reports_access_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_public_reports_access_token ON public.reports USING btree (access_token);


--
-- TOC entry 3542 (class 1259 OID 16768)
-- Name: ix_public_reports_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_created_at ON public.reports USING btree (created_at);


--
-- TOC entry 3543 (class 1259 OID 16769)
-- Name: ix_public_reports_format; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_format ON public.reports USING btree (format);


--
-- TOC entry 3544 (class 1259 OID 16770)
-- Name: ix_public_reports_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_id ON public.reports USING btree (id);


--
-- TOC entry 3545 (class 1259 OID 16771)
-- Name: ix_public_reports_is_public; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_is_public ON public.reports USING btree (is_public);


--
-- TOC entry 3546 (class 1259 OID 16772)
-- Name: ix_public_reports_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_name ON public.reports USING btree (name);


--
-- TOC entry 3547 (class 1259 OID 16773)
-- Name: ix_public_reports_report_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_report_type ON public.reports USING btree (report_type);


--
-- TOC entry 3548 (class 1259 OID 16774)
-- Name: ix_public_reports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_status ON public.reports USING btree (status);


--
-- TOC entry 3549 (class 1259 OID 16775)
-- Name: ix_public_reports_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_reports_workflow_id ON public.reports USING btree (workflow_id);


--
-- TOC entry 3602 (class 1259 OID 16946)
-- Name: ix_public_services_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_services_created_at ON public.services USING btree (created_at);


--
-- TOC entry 3603 (class 1259 OID 16947)
-- Name: ix_public_services_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_services_id ON public.services USING btree (id);


--
-- TOC entry 3604 (class 1259 OID 16948)
-- Name: ix_public_services_is_confirmed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_services_is_confirmed ON public.services USING btree (is_confirmed);


--
-- TOC entry 3605 (class 1259 OID 16949)
-- Name: ix_public_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_services_name ON public.services USING btree (name);


--
-- TOC entry 3606 (class 1259 OID 16950)
-- Name: ix_public_services_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_services_status ON public.services USING btree (status);


--
-- TOC entry 3557 (class 1259 OID 16800)
-- Name: ix_public_subdomains_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_created_at ON public.subdomains USING btree (created_at);


--
-- TOC entry 3558 (class 1259 OID 16801)
-- Name: ix_public_subdomains_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_domain ON public.subdomains USING btree (domain);


--
-- TOC entry 3559 (class 1259 OID 16802)
-- Name: ix_public_subdomains_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_id ON public.subdomains USING btree (id);


--
-- TOC entry 3560 (class 1259 OID 16803)
-- Name: ix_public_subdomains_is_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_is_verified ON public.subdomains USING btree (is_verified);


--
-- TOC entry 3561 (class 1259 OID 16804)
-- Name: ix_public_subdomains_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_name ON public.subdomains USING btree (name);


--
-- TOC entry 3562 (class 1259 OID 16805)
-- Name: ix_public_subdomains_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_status ON public.subdomains USING btree (status);


--
-- TOC entry 3563 (class 1259 OID 16806)
-- Name: ix_public_subdomains_subdomain_part; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_subdomains_subdomain_part ON public.subdomains USING btree (subdomain_part);


--
-- TOC entry 3456 (class 1259 OID 16508)
-- Name: ix_public_targets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_targets_created_at ON public.targets USING btree (created_at);


--
-- TOC entry 3457 (class 1259 OID 16509)
-- Name: ix_public_targets_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_targets_domain ON public.targets USING btree (domain);


--
-- TOC entry 3458 (class 1259 OID 16510)
-- Name: ix_public_targets_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_targets_id ON public.targets USING btree (id);


--
-- TOC entry 3459 (class 1259 OID 16511)
-- Name: ix_public_targets_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_targets_target ON public.targets USING btree (target);


--
-- TOC entry 3489 (class 1259 OID 16581)
-- Name: ix_public_vulnerabilities_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerabilities_created_at ON public.vulnerabilities USING btree (created_at);


--
-- TOC entry 3490 (class 1259 OID 16582)
-- Name: ix_public_vulnerabilities_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerabilities_execution_id ON public.vulnerabilities USING btree (execution_id);


--
-- TOC entry 3491 (class 1259 OID 16583)
-- Name: ix_public_vulnerabilities_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerabilities_id ON public.vulnerabilities USING btree (id);


--
-- TOC entry 3574 (class 1259 OID 16885)
-- Name: ix_public_vulnerability_findings_affected_host; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_affected_host ON public.vulnerability_findings USING btree (affected_host);


--
-- TOC entry 3575 (class 1259 OID 16886)
-- Name: ix_public_vulnerability_findings_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_created_at ON public.vulnerability_findings USING btree (created_at);


--
-- TOC entry 3576 (class 1259 OID 16887)
-- Name: ix_public_vulnerability_findings_cve_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_cve_id ON public.vulnerability_findings USING btree (cve_id);


--
-- TOC entry 3577 (class 1259 OID 16888)
-- Name: ix_public_vulnerability_findings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_id ON public.vulnerability_findings USING btree (id);


--
-- TOC entry 3578 (class 1259 OID 16889)
-- Name: ix_public_vulnerability_findings_is_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_is_verified ON public.vulnerability_findings USING btree (is_verified);


--
-- TOC entry 3579 (class 1259 OID 16890)
-- Name: ix_public_vulnerability_findings_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_severity ON public.vulnerability_findings USING btree (severity);


--
-- TOC entry 3580 (class 1259 OID 16891)
-- Name: ix_public_vulnerability_findings_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_status ON public.vulnerability_findings USING btree (status);


--
-- TOC entry 3581 (class 1259 OID 16892)
-- Name: ix_public_vulnerability_findings_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_title ON public.vulnerability_findings USING btree (title);


--
-- TOC entry 3582 (class 1259 OID 16893)
-- Name: ix_public_vulnerability_findings_vuln_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_vulnerability_findings_vuln_type ON public.vulnerability_findings USING btree (vuln_type);


--
-- TOC entry 3589 (class 1259 OID 16910)
-- Name: ix_public_workflow_executions_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflow_executions_created_at ON public.workflow_executions USING btree (created_at);


--
-- TOC entry 3590 (class 1259 OID 16911)
-- Name: ix_public_workflow_executions_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_public_workflow_executions_execution_id ON public.workflow_executions USING btree (execution_id);


--
-- TOC entry 3591 (class 1259 OID 16912)
-- Name: ix_public_workflow_executions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflow_executions_id ON public.workflow_executions USING btree (id);


--
-- TOC entry 3592 (class 1259 OID 16913)
-- Name: ix_public_workflow_executions_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflow_executions_stage ON public.workflow_executions USING btree (stage);


--
-- TOC entry 3593 (class 1259 OID 16914)
-- Name: ix_public_workflow_executions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflow_executions_status ON public.workflow_executions USING btree (status);


--
-- TOC entry 3497 (class 1259 OID 16626)
-- Name: ix_public_workflows_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflows_created_at ON public.workflows USING btree (created_at);


--
-- TOC entry 3498 (class 1259 OID 16627)
-- Name: ix_public_workflows_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflows_id ON public.workflows USING btree (id);


--
-- TOC entry 3499 (class 1259 OID 16628)
-- Name: ix_public_workflows_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflows_name ON public.workflows USING btree (name);


--
-- TOC entry 3500 (class 1259 OID 16629)
-- Name: ix_public_workflows_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_public_workflows_status ON public.workflows USING btree (status);


--
-- TOC entry 3654 (class 2606 OID 16951)
-- Name: active_recon_results active_recon_results_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_recon_results
    ADD CONSTRAINT active_recon_results_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id);


--
-- TOC entry 3674 (class 2606 OID 17140)
-- Name: archive_findings archive_findings_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archive_findings
    ADD CONSTRAINT archive_findings_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3659 (class 2606 OID 16956)
-- Name: attack_paths attack_paths_kill_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attack_paths
    ADD CONSTRAINT attack_paths_kill_chain_id_fkey FOREIGN KEY (kill_chain_id) REFERENCES public.kill_chains(id);


--
-- TOC entry 3672 (class 2606 OID 17110)
-- Name: breach_records breach_records_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.breach_records
    ADD CONSTRAINT breach_records_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3669 (class 2606 OID 17065)
-- Name: certificate_logs certificate_logs_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificate_logs
    ADD CONSTRAINT certificate_logs_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3676 (class 2606 OID 17170)
-- Name: cloud_assets cloud_assets_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cloud_assets
    ADD CONSTRAINT cloud_assets_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3673 (class 2606 OID 17125)
-- Name: infrastructure_exposures infrastructure_exposures_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infrastructure_exposures
    ADD CONSTRAINT infrastructure_exposures_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3655 (class 2606 OID 16961)
-- Name: kill_chains kill_chains_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kill_chains
    ADD CONSTRAINT kill_chains_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id);


--
-- TOC entry 3656 (class 2606 OID 16966)
-- Name: passive_recon_results passive_recon_results_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passive_recon_results
    ADD CONSTRAINT passive_recon_results_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id);


--
-- TOC entry 3660 (class 2606 OID 16971)
-- Name: ports ports_active_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ports
    ADD CONSTRAINT ports_active_recon_result_id_fkey FOREIGN KEY (active_recon_result_id) REFERENCES public.active_recon_results(id);


--
-- TOC entry 3661 (class 2606 OID 16976)
-- Name: reports reports_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id);


--
-- TOC entry 3662 (class 2606 OID 16981)
-- Name: reports reports_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- TOC entry 3670 (class 2606 OID 17080)
-- Name: repository_findings repository_findings_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repository_findings
    ADD CONSTRAINT repository_findings_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3671 (class 2606 OID 17095)
-- Name: search_dork_results search_dork_results_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_dork_results
    ADD CONSTRAINT search_dork_results_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3666 (class 2606 OID 16991)
-- Name: services services_active_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_active_recon_result_id_fkey FOREIGN KEY (active_recon_result_id) REFERENCES public.active_recon_results(id);


--
-- TOC entry 3667 (class 2606 OID 16986)
-- Name: services services_port_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_port_id_fkey FOREIGN KEY (port_id) REFERENCES public.ports(id);


--
-- TOC entry 3675 (class 2606 OID 17155)
-- Name: social_media_intel social_media_intel_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_media_intel
    ADD CONSTRAINT social_media_intel_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3663 (class 2606 OID 16996)
-- Name: subdomains subdomains_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subdomains
    ADD CONSTRAINT subdomains_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3657 (class 2606 OID 17001)
-- Name: vulnerabilities vulnerabilities_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vulnerabilities
    ADD CONSTRAINT vulnerabilities_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id);


--
-- TOC entry 3664 (class 2606 OID 17006)
-- Name: vulnerability_findings vulnerability_findings_vulnerability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vulnerability_findings
    ADD CONSTRAINT vulnerability_findings_vulnerability_id_fkey FOREIGN KEY (vulnerability_id) REFERENCES public.vulnerabilities(id);


--
-- TOC entry 3668 (class 2606 OID 17050)
-- Name: whois_records whois_records_passive_recon_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whois_records
    ADD CONSTRAINT whois_records_passive_recon_result_id_fkey FOREIGN KEY (passive_recon_result_id) REFERENCES public.passive_recon_results(id);


--
-- TOC entry 3665 (class 2606 OID 17011)
-- Name: workflow_executions workflow_executions_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- TOC entry 3658 (class 2606 OID 17016)
-- Name: workflows workflows_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id);


-- Completed on 2025-08-04 15:51:24 UTC

--
-- PostgreSQL database dump complete
--

